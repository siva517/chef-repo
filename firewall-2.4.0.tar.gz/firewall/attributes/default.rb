default['firewall']['allow_ssh'] = false
default['firewall']['allow_winrm'] = false
